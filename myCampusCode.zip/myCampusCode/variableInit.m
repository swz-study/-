function variableInit()
    global studentNum;%实际总数是studentNum*2
    studentNum = 2000;
    global timeFrame;
    timeFrame = 180; %7:00-9:00
    global end_time;
    end_time = timeFrame;
    global start_time;
    start_time = 0;
    global queue;
    queue = [];
    global server_status;
    server_status = 0;
    global t_service;
    t_service = 0;
    global all_food;%初始状态共1000份食物
    all_food=1000;
    global foodadd;
    foodadd=0;
    global fu;
    fu=1;
    global tf;
    tf=0;
    global foodneed;
    foodneed=[];
end


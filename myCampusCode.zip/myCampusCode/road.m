function [student] = road(student,status)
    switch status
        case 6
            distance = 550;%公寓至教一
        case 8
            distance = 300;%公寓至2食堂
        case 9
            distance = 250;%2食堂至教一
    end
    
    if student.sex == 0%男
        spendTime = distance/normrnd(1.3414,0.0757,1,1);
    else%女
        spendTime = distance/normrnd(1.1629,0.0823,1,1);
    end
    
    student.leaveTime = student.leaveTime+spendTime/3600;
end


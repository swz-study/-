function [Timeline] = manageTimeline(student,Timeline,number,arriveOrLeave)
    leaveTime =  floor((student.leaveTime-7)*60);
    timeFrame= 180;
    for i = leaveTime:timeFrame-1
        Timeline(i+1,number) = Timeline(i+1,number)+arriveOrLeave;
    end
end

 

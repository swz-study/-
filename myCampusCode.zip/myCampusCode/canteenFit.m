function student = canteenFit(student)
%     global studentNum;
%     for n=1:studentNum*2
    canteenWaitingTime = gamrnd(12.2526,3.825)/60;%拟合的等待时间
    if student.sex == 0
        consumeTime = canteenWaitingTime + 8.25;
    else
        consumeTime = canteenWaitingTime + 8.45;
    end
    student.leaveTime = student.leaveTime + consumeTime/60;

end


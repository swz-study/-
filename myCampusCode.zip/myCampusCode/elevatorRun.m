function [stuele] = elevatorRun(stuele,Event_queue)
    global studentNum;
    N=8;%楼层数
    queue = zeros(N,20);
    elevator_loc = 1;%电梯所在楼层
    elevator_num_threshold = 10;%电梯人数上限
    num_in_elevator = 0;%在电梯中的人数
    time_every_floor = 0.0004388; %2.1361/3600s
    elevator_dst = 0;
    queue_in_elevator = [];
    elevator_door = 0;%电梯门的状态    
    while(~isempty(Event_queue))
        [t,type,id,Event_queue]=pop_Event_queue(Event_queue);
        if id >studentNum
           id = id-studentNum;
        end
        %**********************************************************************************************
        if type == -1 %电梯关门
            elevator_door = 0;
            if elevator_loc == 1 
                for i = N:-1:1
                    if queue(i,1) ~= 0
                        elevator_dst = i;
                        break;
                    end
                end
                if i == 1
                    elevator_dst = 0;
                else
                    Event_queue = insert_Event_queue(Event_queue,t+time_every_floor*(elevator_dst-1), 0, elevator_dst);
                end
            else
                time_arrive_next_floor = t + time_every_floor;%去下一层
                Event_queue = insert_Event_queue(Event_queue,time_arrive_next_floor, 0, elevator_loc-1);%insert change event
            end
        %**********************************************************************************************         
        elseif type == 0 %电梯运行
           elevator_loc = id;%电梯楼层
           elevator_door = 1;
           if elevator_loc == 1%出电梯
               while(num_in_elevator ~= 0)
                   temp_id = queue_in_elevator(1);
                   stuele(temp_id).leaveTime = t;%记录下时间
                   queue_in_elevator = queue_in_elevator(2:length(queue_in_elevator));
                   num_in_elevator = num_in_elevator - 1;
               end
        %queue_in_elevator = [];
               elevator_dst = 0;
               time_elevator_close = t + (10 + 50 * rand())/3600;
               Event_queue = insert_Event_queue(Event_queue,time_elevator_close, -1, elevator_loc);%insert close event
           elseif elevator_loc == elevator_dst
               elevator_dst = 1;
               time_elevator_close = t + (10 + 50 * rand())/3600;
               Event_queue = insert_Event_queue(Event_queue,time_elevator_close, -1, elevator_loc);%insert close event
               if queue(elevator_loc,1) ~= 0
                   [queue, pop_id] = pop_queue(queue,elevator_loc,elevator_num_threshold-num_in_elevator);
                    while(~isempty(pop_id))
                        temp_id = pop_id(1);
                        queue_in_elevator = [queue_in_elevator temp_id];%ID放入电梯里
                        num_in_elevator = num_in_elevator + 1;
                        pop_id = pop_id(2:length(pop_id));
                    end
               end
           elseif elevator_dst == 1 
               if queue(elevator_loc,1) ~= 0 && num_in_elevator < elevator_num_threshold%判断是否有人
                   [queue, pop_id] = pop_queue(queue,elevator_loc,elevator_num_threshold-num_in_elevator);
                    while(~isempty(pop_id))%挨层判断
                        temp_id = pop_id(1);
                        queue_in_elevator = [queue_in_elevator temp_id];
                        num_in_elevator = num_in_elevator + 1;
                        pop_id = pop_id(2:length(pop_id));
                    end
                    time_elevator_close = t + (10 + 50 * rand())/3600;
                    Event_queue = insert_Event_queue(Event_queue,time_elevator_close, -1, elevator_loc);%insert close event
               else
                    Event_queue = insert_Event_queue(Event_queue,t+time_every_floor, 0, elevator_loc-1);%insert change event
               end
           end
         %**********************************************************************************************   
        elseif type == 1% 电梯
            if elevator_loc == stuele(id).floor && elevator_door == 1%刚好电梯在并且门开
                    queue_in_elevator = [queue_in_elevator id];
                    num_in_elevator = num_in_elevator + 1;
            elseif queue(stuele(id).floor,1) == 0 %判断当前楼层队列是否为空
                temp_num_in_queue = queue(stuele(id).floor,1);%这一楼层的人数
                queue(stuele(id).floor,temp_num_in_queue+2) = id;
                queue(stuele(id).floor,1) = queue(stuele(id).floor,1) + 1;
                if elevator_loc == 1 && elevator_dst == 0 %刚开始的时候，电梯在一层
                    for i = N:-1:1
                        if queue(i,1) ~= 0
                            elevator_dst = i;
                            break;
                        end
                    end
                    Event_queue = insert_Event_queue(Event_queue,t+time_every_floor*(elevator_dst-1), 0, elevator_dst);%把id换成了楼层
                end
            else %else, join the queue
                temp_num_in_queue = queue(stuele(id).floor,1);
                queue(stuele(id).floor,temp_num_in_queue+2) = id;
                queue(stuele(id).floor,1) = queue(stuele(id).floor,1) + 1;
            end
        end
    end
end


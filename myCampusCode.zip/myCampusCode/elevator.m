function [stu] = elevator(stu,studentNum)%电梯函数返回一个总时间线的值 （时间、状态、人数）
    %*****************init*************************************************
    Event_queue_boy = [];%事件队列
    Event_queue_girl = [];

    N=8;%楼层数
    student_num = studentNum;
    
    for n=1:student_num
        stu(n).floor = unidrnd(N); %floor=1 2 3 4 5 6 7 8 9
        stu(n+student_num).floor = unidrnd(N); 
      	stu(n).leaveTime = 0;%离开电梯时间
      	stu(n+student_num).leaveTime = 0;%离开电梯时间

        if stu(n).floor == 1
            stu(n).leaveTime = stu(n).StartTime;
        else
            Event_queue_boy = insert_Event_queue(Event_queue_boy, stu(n).StartTime, 1,stu(n).id);
        end
        if stu(n+student_num).floor == 1
            stu(n+student_num).leaveTime = stu(n+student_num).StartTime;
        else
            Event_queue_girl = insert_Event_queue(Event_queue_girl, stu(n+student_num).StartTime, 1,stu(n+student_num).id);
        end
    end
    stuboy = stu(1:studentNum);
    stugirl = stu(studentNum+1:2*studentNum);
    stuboy = elevatorRun(stuboy,Event_queue_boy);
    stugirl = elevatorRun(stugirl,Event_queue_girl);
    stu = [stuboy,stugirl];
    
end


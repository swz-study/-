function event_queue=insert_Kitchen_Event_queue(event_queue,time, type)

if isempty(event_queue)
    event_queue = [time;type;0];
else
    s = size(event_queue);
    %check the start and end 
    if event_queue(1,1) >=time
        %add to the start
        event_queue = [[time;type;0] event_queue(:,1:s(2))];
    elseif event_queue(1,s(2)) <=time
        %add to the end
        event_queue = [event_queue(:,1:s(2)) [time;type;0]];
    else
        for n = 1:s(2)-1%go through the event queue and find the right place to insert
            if event_queue(1,n)<time && event_queue(1,n+1)>=time
                %insert the time and type
                event_queue = [event_queue(:,1:n) [time;type;0] event_queue(:,n+1:s(2))];
                break;
            end
        end
    end
	%调整同一时间事件的顺序：补货》检查库存》服务结束》到达
	s = size(event_queue);
	for n=1:s(2)-1
		if event_queue(1,n)==event_queue(1,n+1) && event_queue(2,n)<event_queue(2,n+1)
			a=event_queue(:,n);
			event_queue(:,n)=event_queue(:,n+1);
			event_queue(:,n+1)=a;	
		end
	end
	
	
end
start_time = cputime;
%set the simulation time,unit min
end_time=180;

%%生成结束时间前到达的所有学生及其需要的食品量
%2*n数组，行1为到达时间，行2为食物需求量
%学生到达时间为均值1min的指数分布
%食物需求量{1,2,3,4}，概率分别为1/6,1/3,1/3,1/6
lamda=1;
students=zeros(2,2000);
time_arrival=0;
for n=1:2000
	t1=exprnd(lamda);
	p1=rand();
	if time_arrival+t1<end_time
		students(1,n)=time_arrival+t1;
		time_arrival=time_arrival+t1;
		if p1<=1/6 students(2,n)=1;
			elseif p1<=1/2 students(2,n)=2;
				elseif p1<=5/6 students(2,n)=3;
					else students(2,n)=4;
		end 
    else 

		break;
	end 
end

students=students(:,1:(n-1));

%%事件队列 3*n数组
%行1中保存的为事件发生时间
%行2为事件类型（1到达事件，2服务结束事件，3检查库存事件，4补货事件）
%行3中为到达事件中学生在students数组中的编号，其他事件为0
%事件队列初始化
%存入到达事件
Event_queue=ones(3,length(students));
Event_queue(1,:)=students(1,:);
Event_queue(3,:)=[1:length(students)];
%存入检查库存事件
for n=1:end_time
	if mod(n,30)==0 
		Event_queue=insert_Kitchen_Event_queue(Event_queue,n,3);
	end
end

%%学生排队队列，保存的是未获服务的学生在students数组中的序号
queue= [];
%当前服务学生序号
id=1;

%%库存初始化
S=80;%补货量
s=40;%门限值
stock=40;%库存量

%%服务状态，1为忙，0为闲
server_status = 0;
t_service = 0;

%set the record values for statistic
wait_time = [];
busy_time = 0;

%now start the time series
t=0;
%服务时间为gamma分布，参数为A、B
A=0.2042;%12.2527;
B=0.0638;
while(t<end_time)%keep moving as long as t less than end_time
    
    %检查事件队列中是否有事件
    if isempty(Event_queue)
        %事件队列为空，结束仿真
        break
    else%事件队列不空则从中取一事件
        [t,type,id,Event_queue]=pop_Event_queue(Event_queue);
    end
    
    %检查事件类型
    if type == 1%到达事件
        %检查学生队列中是否有人排队        
        if isempty(queue)
			%如果学生队列中无人检查服务状态
            if server_status == 0
				%如果服务状态为闲检查食品存量
				if stock>=students(2,id)
					%如果库存大于需求则接受服务
					t_service=t+gamrnd(A,B);
					%判断服务结束时间并把服务结束事件加入事件队列
					Event_queue=insert_Kitchen_Event_queue(Event_queue,t_service, 2);
					server_status = 1;%set the server into busy
					stock=stock-students(2,id);
					%record something
					wait_time=[wait_time 0];
					busy_time=busy_time+t_service-t;
				else%如果库存小于需求则加入学生队列
					queue=[queue id];
				end
            else%如果服务状态为忙加入学生队列
                queue=[queue id];
            end
        else%如果学生队列中有人排队则加入学生队列
            queue=[queue id];    
        end
        
    elseif type==2%服务结束事件
       if server_status==1
           server_status=0;
           t_service=0;

           %检查学生队列中是否有人排队
           if ~isempty(queue)
            %如果有人排队从学生队列队首取一人
				id=queue(1);
                queue=queue(2:length(queue));
                %检查食品存量
				if stock>=students(2,id)
					%如果库存大于需求则接受服务
					t_service=t+gamrnd(A,B);
					%判断服务结束时间并把服务结束事件加入事件队列
					Event_queue=insert_Kitchen_Event_queue(Event_queue,t_service, 2);
					server_status = 1;%set the server into busy
					stock=stock-students(2,id);
					%record something
					wait_time=[wait_time t-students(1,id)];
					busy_time=busy_time+t_service-t;
				else%如果库存小于需求则加入学生队列
					queue=[queue id];
				end
           else
               %do nothing, waiting for next customer
           end       
        end
		
	elseif type==3%检查库存事件
		if stock<s%如果库存小于门限值就将补货事件存入事件队列
			t2=15+15*rand();
			Event_queue=insert_Kitchen_Event_queue(Event_queue,t+t2, 4);
		end 

	elseif type==4%补货事件
		stock=stock+S;
		if ~isempty(queue)
			id=queue(1);
            queue=queue(2:length(queue));
			t_service=t+gamrnd(A,B);
			%判断服务结束时间并把服务结束事件加入事件队列
			Event_queue=insert_Kitchen_Event_queue(Event_queue,t_service, 2);
			server_status = 1;%set the server into busy
			stock=stock-students(2,id);
			%record something
			wait_time=[wait_time t-students(1,id)];
			busy_time=busy_time+t_service-t;
		end
		
    end
       
end
for n=1:length(queue)
	wait_time=[wait_time end_time-students(1,queue(n))];
end

wait_sim=mean(wait_time)

utilization=busy_time/end_time
plot(wait_time)

last_time = cputime - start_time


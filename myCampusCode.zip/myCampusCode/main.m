clc;clear;
close all;

variableInit();
generateStudentNum = 2700;
global studentNum;
global timeFrame;
%1、公寓内男女起床、洗漱时间
wakeupTimeBoy = normrnd(7.633,0.7822,1,generateStudentNum);
wakeupTimeGirl = normrnd(7.567,0.4761,1,generateStudentNum);
washTimeBoy = gamrnd(0.05682,0.05188,1,generateStudentNum);
washTimeGirl = normrnd(0.2886,0.1428,1,generateStudentNum);
timeBoy = sort(wakeupTimeBoy+washTimeBoy);
timeBoy = timeBoy(timeBoy>=7&timeBoy<=10);
timeBoy = timeBoy(1:studentNum);
timeGirl = sort(wakeupTimeGirl+washTimeGirl);
timeGirl = timeGirl(timeGirl>=7&timeGirl<=10);
timeGirl = timeGirl(1:studentNum);

Timeline = zeros(timeFrame,10);%总时间线
for n=1:timeFrame
    Timeline(n,5)=studentNum;
    Timeline(n,7)=studentNum;
end
for n=1:studentNum
    stu(n) = student;
    stu(n).id = n;
    stu(n).sex = 0;
    stu(n).StartTime = timeBoy(n);
    
    stu(studentNum+n) = student;
    stu(studentNum+n).id = studentNum+n;
    stu(studentNum+n).sex = 1;
    stu(studentNum+n).StartTime = timeGirl(n);
end
%2、乘坐电梯
stu = elevator(stu,studentNum);

for n=1:studentNum
    [Timeline] = manageTimeline(stu(n),Timeline,5,-1);
    [Timeline] = manageTimeline(stu(studentNum+n),Timeline,7,-1);
end
%3、食堂，超市，邮局，路程时间消耗
allTime = 0;

for n=1:studentNum*2 
    proba =  round(rand());%去1，2食堂概率各为50%
    if proba == 0 %先去食堂一
        Timeline = manageTimeline(stu(n),Timeline,1,1);
        stu(n) = canteenFit(stu(n));
        Timeline = manageTimeline(stu(n),Timeline,1,-1);
        if unifrnd(0,1)<0.03
            Timeline = manageTimeline(stu(n),Timeline,3,1);
            stu(n) = marketOrExpress(stu(n));
            Timeline = manageTimeline(stu(n),Timeline,3,-1);
        end
        if unifrnd(0,1)<0.01
            Timeline = manageTimeline(stu(n),Timeline,4,1);
            stu(n) = marketOrExpress(stu(n));
            Timeline = manageTimeline(stu(n),Timeline,4,-1);
        end
        Timeline = manageTimeline(stu(n),Timeline,6,1);
        stu(n) = road(stu(n),6);
        Timeline = manageTimeline(stu(n),Timeline,6,-1);
    else
        if unifrnd(0,1)<0.03
            Timeline = manageTimeline(stu(n),Timeline,3,1);
            stu(n) = marketOrExpress(stu(n));
            Timeline = manageTimeline(stu(n),Timeline,3,-1);
        end
        if unifrnd(0,1)<0.01
            Timeline = manageTimeline(stu(n),Timeline,4,1);
            stu(n) = marketOrExpress(stu(n));
            Timeline = manageTimeline(stu(n),Timeline,4,-1);
        end
        Timeline = manageTimeline(stu(n),Timeline,8,1);
        stu(n) = road(stu(n),8);
        Timeline = manageTimeline(stu(n),Timeline,8,-1);
        
        Timeline = manageTimeline(stu(n),Timeline,2,1);
        stu(n) = canteenFit(stu(n));
        Timeline = manageTimeline(stu(n),Timeline,2,-1);
        
        Timeline = manageTimeline(stu(n),Timeline,9,1);
        stu(n) = road(stu(n),9);
        Timeline = manageTimeline(stu(n),Timeline,9,-1);
    end
    Timeline = manageTimeline(stu(n),Timeline,10,1);
    stu(n).allSpendTime = stu(n).leaveTime-stu(n).StartTime;
	allTime = allTime + stu(n).allSpendTime;
end

averageSpendTime = (allTime/(studentNum*2))*60

GKDgraph(Timeline,averageSpendTime);


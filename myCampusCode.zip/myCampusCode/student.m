classdef student
    properties
        id
        StartTime
        sex
        floor
        leaveTime%离开电梯时间
        allSpendTime
    end
end
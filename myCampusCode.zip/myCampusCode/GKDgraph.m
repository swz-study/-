function GKDgraph(Timeline,averageSpendTime)
    C = imread('GKD.png');
    imshow(C);
    hold on
    NodeLoc=[
        227 150;%一食堂
        139 363;%二食堂
        258 157;%超市
        249 191;%驿站
        188 40;%五公寓
        218 98;%7公寓
        260 522%教一
        ];
    for timecircle=1:180
        timenow = timecircle;
        HourNow = num2str(7+floor(timenow/60));
        MinNow = num2str(mod(timenow,60));
        C = imread('GKD.png');
        title(['现在时间为：',HourNow,':',MinNow,'  平均用时:',num2str(averageSpendTime),'mins']);
        imshow(C);
        hold on
        a(1) = Timeline(timenow,1)+1;
        a(2) = Timeline(timenow,2)+1;
        a(3) = Timeline(timenow,3)+1;
        a(4) = Timeline(timenow,4)+1;
        a(5) = Timeline(timenow,5)+1;
        a(6) = Timeline(timenow,7)+1;
        a(7) = Timeline(timenow,10)+1;
        a(10) = int8(Timeline(timenow,9))+1;

        a(8) = int8(Timeline(timenow,6))+1;
        a(9) = int8(Timeline(timenow,8))+1;
        for i=1:7
            scatter(NodeLoc(i,1),NodeLoc(i,2),a(i),'filled');
        end

        NodeSleepTolearn1 = [237 193;227 278;191 297;185 363;181 487;240 492];%公寓至教一
        NodeC1ToC2 = [237 193;227 278;191 297;185 363];
        NodeC2Tolearn1 = [185 363;181 487;240 492];
        EdgeList1=[1 2;2 3;3 4;4 5;5 6];

        for i = 1:5
            n_s=EdgeList1(i,1);
            n_d=EdgeList1(i,2);
            line([NodeSleepTolearn1(n_s,1) NodeSleepTolearn1(n_d,1)],[NodeSleepTolearn1(n_s,2) NodeSleepTolearn1(n_d,2)],'LineWidth',a(8)/20);    
        end
        for i = 1:3
            n_s=EdgeList1(i,1);
            n_d=EdgeList1(i,2);
            line([NodeC1ToC2(n_s,1) NodeC1ToC2(n_d,1)],[NodeC1ToC2(n_s,2) NodeC1ToC2(n_d,2)],'LineWidth',a(9)/20);    
        end
        for i = 1:2
            n_s=EdgeList1(i,1);
            n_d=EdgeList1(i,2);
            line([NodeC2Tolearn1(n_s,1) NodeC2Tolearn1(n_d,1)],[NodeC2Tolearn1(n_s,2) NodeC2Tolearn1(n_d,2)],'LineWidth',a(10)/20);    
        end
        frame = getframe(gcf);  %捕获坐标区或图窗作为影⽚帧  %gcf是返回的figure，f是figure的⾸字母
        A = frame2im(frame);   %返回与影⽚帧关联的图像数据
        [A,map]=rgb2ind(A,256); %将RGB 图像转换为索引图像I，关联颜⾊图为 map
        cla;
        if timecircle == 1
            imwrite(A,map,'test.gif','gif','LoopCount',inf,'DelayTime',0.2); %0.2是延时时间
        else
             imwrite(A,map,'test.gif','gif','WriteMode','append','DelayTime',0.2);
        end
    end
%     movie(A,2)
end




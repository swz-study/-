function student = marketOrExpress(student)
    supermarketWaitingTime = exprnd(67.667)+normrnd(31.5185,12.6979);%等待时间+结账时间/查找快递+取快递
    student.leaveTime = student.leaveTime + supermarketWaitingTime/60;
end
